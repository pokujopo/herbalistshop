
import { useEffect, useMemo, useState } from "react";
import adminApi from "../services/adminApi";

function AdminCategories() {
  const [categories, setCategories] = useState([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  const [editingId, setEditingId] = useState(null);
  const [preview, setPreview] = useState(null);

  const [form, setForm] = useState({
    name: "",
    slug: "",
    description: "",
    is_active: true,
  });

  const [image, setImage] = useState(null);
  const [query, setQuery] = useState("");

  const fetchCategories = async () => {
    try {
      setLoading(true);
      const res = await adminApi.get("/categories");
      setCategories(res.data.data || res.data.categories || []);
    } catch (error) {
      console.log(error.response?.data || error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchCategories();
  }, []);

  const filteredCategories = useMemo(() => {
    if (!query.trim()) return categories;

    const q = query.toLowerCase();
    return categories.filter((item) =>
      item.name?.toLowerCase().includes(q) ||
      item.slug?.toLowerCase().includes(q)
    );
  }, [categories, query]);

  const resetForm = () => {
    setForm({
      name: "",
      slug: "",
      description: "",
      is_active: true,
    });
    setImage(null);
    setPreview(null);
    setEditingId(null);
  };

  const handleChange = (e) => {
    const { name, value, type, checked } = e.target;

    setForm((prev) => ({
      ...prev,
      [name]: type === "checkbox" ? checked : value,
    }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    setImage(file);

    if (file) {
      setPreview(URL.createObjectURL(file));
    }
  };

  const handleEdit = (item) => {
    setEditingId(item.id);
    setForm({
      name: item.name || "",
      slug: item.slug || "",
      description: item.description || "",
      is_active: !!item.is_active,
    });
    setPreview(item.image || null);
    setImage(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const formData = new FormData();
    formData.append("name", form.name);
    formData.append("slug", form.slug);
    formData.append("description", form.description);
    formData.append("is_active", form.is_active ? "1" : "0");

    if (image) {
      formData.append("image", image);
    }

    try {
      setSaving(true);

      if (editingId) {
        await adminApi.post(`/admin/categories/${editingId}`, formData);
        alert("Category updated successfully");
      } else {
        await adminApi.post("/admin/categories", formData);
        alert("Category created successfully");
      }

      resetForm();
      fetchCategories();
    } catch (error) {
      console.log(error.response?.data || error);
      alert(error.response?.data?.message || "Failed to save category");
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id) => {
    const ok = window.confirm("Una uhakika unataka kufuta category hii?");
    if (!ok) return;

    try {
      await adminApi.delete(`/admin/categories/${id}`);
      setCategories((prev) => prev.filter((item) => item.id !== id));
      if (editingId === id) resetForm();
      alert("Category deleted successfully");
    } catch (error) {
      console.log(error.response?.data || error);
      alert(error.response?.data?.message || "Failed to delete category");
    }
  };

  const generateSlug = (value) => {
    return value
      .toLowerCase()
      .trim()
      .replace(/\s+/g, "-")
      .replace(/[^\w-]+/g, "");
  };

  return (
    <div className="space-y-5">
      {/* FORM */}
      <div className="bg-white rounded-2xl shadow-sm p-5">
        <h2 className="text-xl font-bold text-gray-800 mb-5">
          {editingId ? "Edit Category" : "Create Category"}
        </h2>

        <form onSubmit={handleSubmit} className="grid gap-4">
          <input
            type="text"
            name="name"
            placeholder="Category name"
            value={form.name}
            onChange={(e) => {
              handleChange(e);
              if (!editingId) {
                setForm((prev) => ({
                  ...prev,
                  slug: generateSlug(e.target.value),
                }));
              }
            }}
            className="border rounded-lg p-3"
            required
          />

          <input
            type="text"
            name="slug"
            placeholder="category-slug"
            value={form.slug}
            onChange={handleChange}
            className="border rounded-lg p-3"
            required
          />

          <textarea
            name="description"
            placeholder="Category description"
            value={form.description}
            onChange={handleChange}
            className="border rounded-lg p-3"
            rows={4}
          />

          <input
            type="file"
            accept="image/*"
            onChange={handleImageChange}
            className="border rounded-lg p-3"
          />

          {preview && (
            <div className="w-40 aspect-square overflow-hidden rounded-xl border">
              <img
                src={preview}
                alt="Preview"
                className="w-full h-full object-cover"
              />
            </div>
          )}

          <label className="flex items-center gap-2">
            <input
              type="checkbox"
              name="is_active"
              checked={form.is_active}
              onChange={handleChange}
            />
            Active
          </label>

          <div className="flex gap-3">
            <button
              type="submit"
              disabled={saving}
              className="bg-green-600 text-white rounded-xl py-3 px-6 font-semibold hover:bg-green-700 transition"
            >
              {saving ? "Saving..." : editingId ? "Update Category" : "Create Category"}
            </button>

            {editingId && (
              <button
                type="button"
                onClick={resetForm}
                className="bg-gray-200 text-gray-800 rounded-xl py-3 px-6 font-semibold hover:bg-gray-300 transition"
              >
                Cancel
              </button>
            )}
          </div>
        </form>
      </div>

      {/* TABLE / GRID */}
      <div className="bg-white rounded-2xl shadow-sm p-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4 mb-5">
          <h2 className="text-xl font-bold text-gray-800">Categories</h2>

          <input
            type="text"
            placeholder="Search category..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500 md:w-72"
          />
        </div>

        {loading ? (
          <p className="text-gray-500">Loading categories...</p>
        ) : filteredCategories.length === 0 ? (
          <p className="text-gray-500">Hakuna categories zilizopatikana.</p>
        ) : (
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredCategories.map((item) => (
              <div key={item.id} className="border rounded-2xl p-4 bg-gray-50">
                <div className="flex items-start gap-4">
                  <div className="w-20 aspect-square rounded-xl overflow-hidden bg-white border shrink-0">
                    {item.image ? (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="w-full h-full object-cover"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-gray-400 text-xs">
                        No Image
                      </div>
                    )}
                  </div>

                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-gray-800">{item.name}</h3>
                    <p className="text-sm text-gray-500">{item.slug}</p>
                    <p className="text-sm text-gray-400 mt-2 line-clamp-2">
                      {item.description || "No description"}
                    </p>

                    <div className="mt-3">
                      {item.is_active ? (
                        <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded">
                          Active
                        </span>
                      ) : (
                        <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">
                          Inactive
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                <div className="mt-4 flex gap-2">
                  <button
                    onClick={() => handleEdit(item)}
                    className="px-3 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 text-sm"
                  >
                    Edit
                  </button>

                  <button
                    onClick={() => handleDelete(item.id)}
                    className="px-3 py-2 rounded-lg bg-red-500 text-white hover:bg-red-600 text-sm"
                  >
                    Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

export default AdminCategories;