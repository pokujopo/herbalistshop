import { useEffect, useState } from "react";
import adminApi from "../services/adminApi";

function AdminCoupons() {
  const [coupons, setCoupons] = useState([]);
  const [saving, setSaving] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState({ code: "", discount_percent: "", is_active: true, expires_at: "" });

  const fetchCoupons = async () => {
    const res = await adminApi.get("/admin/coupons");
    setCoupons(res.data.data?.data || []);
  };

  useEffect(() => { fetchCoupons(); }, []);

  const resetForm = () => {
    setForm({ code: "", discount_percent: "", is_active: true, expires_at: "" });
    setEditingId(null);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      setSaving(true);
      if (editingId) {
        await adminApi.post(`/admin/coupons/${editingId}`, { ...form, is_active: !!form.is_active });
        alert("Coupon updated successfully");
      } else {
        await adminApi.post("/admin/coupons", { ...form, is_active: !!form.is_active });
        alert("Coupon created successfully");
      }
      resetForm();
      fetchCoupons();
    } finally {
      setSaving(false);
    }
  };

  const handleEdit = (item) => {
    setEditingId(item.id);
    setForm({
      code: item.code || "",
      discount_percent: item.discount_percent || "",
      is_active: !!item.is_active,
      expires_at: item.expires_at ? item.expires_at.slice(0, 10) : "",
    });
  };

  const handleDelete = async (id) => {
    const ok = window.confirm("Delete coupon?");
    if (!ok) return;
    await adminApi.delete(`/admin/coupons/${id}`);
    fetchCoupons();
  };

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl shadow-sm p-5">
        <h2 className="text-xl font-bold mb-5">{editingId ? "Edit Coupon" : "Create Coupon"}</h2>
        <form onSubmit={handleSubmit} className="grid gap-4">
          <input value={form.code} onChange={(e) => setForm({ ...form, code: e.target.value })} placeholder="Coupon code" className="border rounded-lg p-3" required />
          <input type="number" value={form.discount_percent} onChange={(e) => setForm({ ...form, discount_percent: e.target.value })} placeholder="Discount percent" className="border rounded-lg p-3" required />
          <input type="date" value={form.expires_at} onChange={(e) => setForm({ ...form, expires_at: e.target.value })} className="border rounded-lg p-3" />
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={form.is_active} onChange={(e) => setForm({ ...form, is_active: e.target.checked })} />
            Active
          </label>
          <div className="flex gap-3">
            <button type="submit" disabled={saving} className="bg-green-600 text-white px-6 py-3 rounded-xl hover:bg-green-700">
              {saving ? "Saving..." : editingId ? "Update Coupon" : "Create Coupon"}
            </button>
            {editingId && <button type="button" onClick={resetForm} className="bg-gray-200 text-gray-800 px-6 py-3 rounded-xl hover:bg-gray-300">Cancel</button>}
          </div>
        </form>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-5">
        <h2 className="text-xl font-bold mb-5">Coupons</h2>
        <div className="space-y-3">
          {coupons.map((item) => (
            <div key={item.id} className="border rounded-xl p-4 flex justify-between items-center">
              <div>
                <p className="font-semibold">{item.code}</p>
                <p className="text-sm text-gray-500">{item.discount_percent}% off</p>
              </div>
              <div className="flex gap-2">
                <button onClick={() => handleEdit(item)} className="px-3 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 text-sm">Edit</button>
                <button onClick={() => handleDelete(item.id)} className="px-3 py-2 rounded-lg bg-red-500 text-white hover:bg-red-600 text-sm">Delete</button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default AdminCoupons;
