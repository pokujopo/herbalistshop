import { useEffect, useState } from "react";
import adminApi from "../services/adminApi";

function AdminSettings() {
  const [form, setForm] = useState({
    store_name: "", store_email: "", store_phone: "", store_address: "",
    facebook_url: "", instagram_url: "", twitter_url: "",
  });
  const [logo, setLogo] = useState(null);
  const [preview, setPreview] = useState(null);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const load = async () => {
      const res = await adminApi.get("/admin/settings");
      if (res.data.setting) {
        setForm({
          store_name: res.data.setting.store_name || "",
          store_email: res.data.setting.store_email || "",
          store_phone: res.data.setting.store_phone || "",
          store_address: res.data.setting.store_address || "",
          facebook_url: res.data.setting.facebook_url || "",
          instagram_url: res.data.setting.instagram_url || "",
          twitter_url: res.data.setting.twitter_url || "",
        });
        setPreview(res.data.setting.logo || null);
      }
    };
    load();
  }, []);

  const handleChange = (e) => setForm((prev) => ({ ...prev, [e.target.name]: e.target.value }));

  const handleLogoChange = (e) => {
    const file = e.target.files[0];
    setLogo(file);
    if (file) setPreview(URL.createObjectURL(file));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const formData = new FormData();
    Object.entries(form).forEach(([k, v]) => formData.append(k, v));
    if (logo) formData.append("logo", logo);

    try {
      setSaving(true);
      await adminApi.post("/admin/settings", formData);
      alert("Settings saved successfully");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="bg-white rounded-2xl shadow-sm p-5">
      <h2 className="text-xl font-bold mb-5">Store Settings</h2>
      <form onSubmit={handleSubmit} className="grid gap-4">
        <input name="store_name" value={form.store_name} onChange={handleChange} placeholder="Store name" className="border rounded-lg p-3" />
        <input name="store_email" value={form.store_email} onChange={handleChange} placeholder="Store email" className="border rounded-lg p-3" />
        <input name="store_phone" value={form.store_phone} onChange={handleChange} placeholder="Store phone" className="border rounded-lg p-3" />
        <input name="store_address" value={form.store_address} onChange={handleChange} placeholder="Store address" className="border rounded-lg p-3" />
        <input name="facebook_url" value={form.facebook_url} onChange={handleChange} placeholder="Facebook URL" className="border rounded-lg p-3" />
        <input name="instagram_url" value={form.instagram_url} onChange={handleChange} placeholder="Instagram URL" className="border rounded-lg p-3" />
        <input name="twitter_url" value={form.twitter_url} onChange={handleChange} placeholder="Twitter URL" className="border rounded-lg p-3" />
        <input type="file" accept="image/*" onChange={handleLogoChange} className="border rounded-lg p-3" />
        {preview && <div className="w-32 aspect-square rounded-xl overflow-hidden border"><img src={preview} alt="Logo" className="w-full h-full object-cover" /></div>}
        <button type="submit" disabled={saving} className="bg-green-600 text-white px-6 py-3 rounded-xl hover:bg-green-700">
          {saving ? "Saving..." : "Save Settings"}
        </button>
      </form>
    </div>
  );
}

export default AdminSettings;
