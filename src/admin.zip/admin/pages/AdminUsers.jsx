import { useEffect, useState } from "react";
import adminApi from "../services/adminApi";

function AdminUsers() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [role, setRole] = useState("all");
  const [status, setStatus] = useState("all");
  const [selectedUser, setSelectedUser] = useState(null);
  const [saving, setSaving] = useState(false);

  const fetchUsers = async () => {
    try {
      setLoading(true);
      const params = new URLSearchParams();
      if (query) params.set("search", query);
      if (role !== "all") params.set("role", role);
      if (status !== "all") params.set("status", status);
      const res = await adminApi.get(`/admin/users?${params.toString()}`);
      setUsers(res.data.data || []);
    } catch (err) {
      console.log(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => { fetchUsers(); }, []);

  const openUser = async (id) => {
    const res = await adminApi.get(`/admin/users/${id}`);
    setSelectedUser(res.data.user);
  };

  const saveUser = async () => {
    try {
      setSaving(true);
      const res = await adminApi.put(`/admin/users/${selectedUser.id}`, {
        role: selectedUser.role,
        is_active: selectedUser.is_active,
      });
      setSelectedUser(res.data.user);
      fetchUsers();
      alert("User updated");
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-5">
      <div className="bg-white p-5 rounded-2xl shadow-sm">
        <h2 className="text-xl font-bold">Customers</h2>
        <div className="grid md:grid-cols-3 gap-4 mt-4">
          <input placeholder="Search name or email..." value={query} onChange={(e) => setQuery(e.target.value)} className="border p-3 rounded-xl" />
          <select value={role} onChange={(e) => setRole(e.target.value)} className="border p-3 rounded-xl">
            <option value="all">All Roles</option><option value="user">User</option><option value="admin">Admin</option>
          </select>
          <select value={status} onChange={(e) => setStatus(e.target.value)} className="border p-3 rounded-xl">
            <option value="all">All Status</option><option value="active">Active</option><option value="inactive">Blocked</option>
          </select>
        </div>
        <button onClick={fetchUsers} className="mt-4 bg-green-600 text-white px-6 py-2 rounded-xl">Search</button>
      </div>

      <div className="bg-white p-5 rounded-2xl shadow-sm">
        {loading ? <p>Loading...</p> : (
          <table className="w-full text-sm">
            <thead><tr className="border-b"><th>Name</th><th>Email</th><th>Orders</th><th>Role</th><th>Status</th><th></th></tr></thead>
            <tbody>
              {users.map((u) => (
                <tr key={u.id} className="border-b">
                  <td>{u.name}</td><td>{u.email}</td><td>{u.orders_count}</td><td>{u.role}</td><td>{u.is_active ? "Active" : "Blocked"}</td>
                  <td><button onClick={() => openUser(u.id)} className="text-blue-600">View</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {selectedUser && (
        <div className="bg-white p-5 rounded-2xl shadow-sm">
          <h3 className="font-bold text-lg">{selectedUser.name}</h3>
          <div className="grid md:grid-cols-2 gap-4 mt-4">
            <div>
              <label>Role</label>
              <select value={selectedUser.role} onChange={(e) => setSelectedUser({ ...selectedUser, role: e.target.value })} className="border p-3 rounded-xl w-full">
                <option value="user">User</option><option value="admin">Admin</option>
              </select>
            </div>
            <div>
              <label>Status</label>
              <select value={selectedUser.is_active ? "active" : "inactive"} onChange={(e) => setSelectedUser({ ...selectedUser, is_active: e.target.value === "active" })} className="border p-3 rounded-xl w-full">
                <option value="active">Active</option><option value="inactive">Blocked</option>
              </select>
            </div>
          </div>
          <div className="mt-6">
            <h4 className="font-semibold">Orders</h4>
            {selectedUser.orders?.length === 0 ? <p>No orders</p> : selectedUser.orders.map((o) => (
              <div key={o.id} className="border p-3 rounded-xl mt-2">#{o.order_number} - {o.order_status}</div>
            ))}
          </div>
          <button onClick={saveUser} disabled={saving} className="mt-5 bg-green-600 text-white px-6 py-3 rounded-xl">Save Changes</button>
        </div>
      )}
    </div>
  );
}

export default AdminUsers;
