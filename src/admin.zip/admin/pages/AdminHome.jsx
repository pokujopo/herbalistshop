import { useEffect, useState } from "react";
import adminApi from "../services/adminApi";

function StatCard({ title, value, subtitle }) {
  return (
    <div className="bg-white rounded-2xl shadow-sm p-5">
      <p className="text-sm text-gray-500">{title}</p>
      <h3 className="text-2xl font-bold text-gray-800 mt-2">{value}</h3>
      {subtitle && <p className="text-xs text-gray-400 mt-1">{subtitle}</p>}
    </div>
  );
}

function AdminHome() {
  const [data, setData] = useState(null);

  useEffect(() => {
    const load = async () => {
      try {
        const res = await adminApi.get("/admin/dashboard/analytics");
        setData(res.data);
      } catch (error) {
        console.log(error.response?.data || error);
      }
    };

    load();
  }, []);

  if (!data) {
    return <p className="text-gray-500">Loading dashboard...</p>;
  }

  const { stats, recent_orders, low_stock_products, monthly_sales } = data;

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-3 lg:grid-cols-6 gap-4">
        <StatCard title="Orders" value={stats.orders} />
        <StatCard title="Products" value={stats.products} />
        <StatCard title="Customers" value={stats.customers} />
        <StatCard title="Revenue" value={`TZS ${Number(stats.revenue).toLocaleString()}`} />
        <StatCard title="Today Orders" value={stats.today_orders} />
        <StatCard title="Today Revenue" value={`TZS ${Number(stats.today_revenue).toLocaleString()}`} />
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-5">
        <h2 className="text-lg font-bold mb-4">Monthly Sales</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-3">
          {monthly_sales.map((item) => (
            <div key={item.month} className="bg-gray-50 rounded-xl p-4 text-center">
              <p className="text-sm text-gray-500">{item.month}</p>
              <p className="font-semibold text-gray-800 mt-2">
                {Number(item.total).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-2xl shadow-sm p-5">
          <h2 className="text-lg font-bold mb-4">Recent Orders</h2>
          <div className="space-y-3">
            {recent_orders.length === 0 ? (
              <p className="text-gray-500 text-sm">Hakuna orders bado.</p>
            ) : (
              recent_orders.map((order) => (
                <div key={order.id} className="border rounded-xl p-4">
                  <p className="font-semibold">{order.order_number}</p>
                  <p className="text-sm text-gray-500">
                    {order.address?.full_name || order.user?.name || "-"}
                  </p>
                  <p className="text-sm text-green-600 font-medium mt-1">
                    TZS {Number(order.total).toLocaleString()}
                  </p>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="bg-white rounded-2xl shadow-sm p-5">
          <h2 className="text-lg font-bold mb-4">Low Stock Products</h2>
          <div className="space-y-3">
            {low_stock_products.length === 0 ? (
              <p className="text-gray-500 text-sm">Hakuna low stock products.</p>
            ) : (
              low_stock_products.map((product) => (
                <div key={product.id} className="border rounded-xl p-4 flex items-center gap-4">
                  <div className="w-14 aspect-square rounded-lg overflow-hidden bg-gray-100">
                    <img src={product.thumbnail} alt={product.name} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="font-semibold text-gray-800">{product.name}</p>
                    <p className="text-sm text-gray-500">{product.category?.name || "-"}</p>
                  </div>
                  <span className="text-sm bg-red-100 text-red-700 px-3 py-1 rounded-full">
                    Stock: {product.stock}
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

export default AdminHome;
