import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import adminApi from "../services/adminApi";

function AdminProducts() {
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState("all");

  const fetchProducts = async () => {
    try {
      setLoading(true);
      const res = await adminApi.get("/products");
      setProducts(res.data?.data || []);
    } catch (error) {
      console.log("Products error:", error.response?.data || error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchProducts();
  }, []);

  const filteredProducts = useMemo(() => {
    let items = [...products];
    if (query.trim()) {
      const q = query.toLowerCase();
      items = items.filter((item) =>
        item.name?.toLowerCase().includes(q) ||
        item.slug?.toLowerCase().includes(q) ||
        item.sku?.toLowerCase().includes(q)
      );
    }
    if (filter === "featured") items = items.filter((item) => item.is_featured);
    if (filter === "best") items = items.filter((item) => item.is_best_seller);
    if (filter === "new") items = items.filter((item) => item.is_new);
    if (filter === "inactive") items = items.filter((item) => !item.is_active);
    return items;
  }, [products, query, filter]);

  const handleDelete = async (id) => {
    const ok = window.confirm("Una uhakika unataka kufuta product hii?");
    if (!ok) return;
    try {
      await adminApi.delete(`/products/${id}`);
      setProducts((prev) => prev.filter((item) => item.id !== id));
      alert("Product deleted successfully");
    } catch (error) {
      console.log(error.response?.data || error);
      alert(error.response?.data?.message || "Failed to delete product");
    }
  };

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl shadow-sm p-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-gray-800">Products</h2>
            <p className="text-sm text-gray-500">Simamia bidhaa zote za shop yako</p>
          </div>
          <Link to="/admin/products/create" className="bg-green-600 text-white px-4 py-2 rounded-xl hover:bg-green-700">
            Add Product
          </Link>
        </div>

        <div className="mt-5 grid md:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder="Search by name, slug, SKU..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
          />
          <select
            value={filter}
            onChange={(e) => setFilter(e.target.value)}
            className="border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="all">All Products</option>
            <option value="featured">Featured</option>
            <option value="best">Best Seller</option>
            <option value="new">New</option>
            <option value="inactive">Inactive</option>
          </select>
          <div className="flex items-center text-sm text-gray-500">Total: {filteredProducts.length}</div>
        </div>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-5">
        {loading ? (
          <p className="text-gray-500">Loading products...</p>
        ) : filteredProducts.length === 0 ? (
          <p className="text-gray-500">Hakuna products zilizopatikana.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[1000px]">
              <thead>
                <tr className="text-left text-gray-500 border-b">
                  <th className="py-3">Image</th>
                  <th className="py-3">Product</th>
                  <th className="py-3">Category</th>
                  <th className="py-3">Price</th>
                  <th className="py-3">Stock</th>
                  <th className="py-3">Flags</th>
                  <th className="py-3">Status</th>
                  <th className="py-3">Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((item) => (
                  <tr key={item.id} className="border-b last:border-0">
                    <td className="py-3">
                      <div className="w-14 aspect-square rounded-lg overflow-hidden bg-gray-100">
                        <img src={item.thumbnail} alt={item.name} className="w-full h-full object-cover" />
                      </div>
                    </td>
                    <td className="py-3">
                      <p className="font-semibold text-gray-800">{item.name}</p>
                      <p className="text-xs text-gray-500">{item.slug}</p>
                    </td>
                    <td className="py-3">{item.category?.name || "-"}</td>
                    <td className="py-3">
                      <div className="flex flex-col">
                        <span className="font-semibold text-green-600">
                          TZS {Number(item.discount_price || item.price).toLocaleString()}
                        </span>
                        {item.discount_price && (
                          <span className="text-xs text-gray-400 line-through">
                            TZS {Number(item.price).toLocaleString()}
                          </span>
                        )}
                      </div>
                    </td>
                    <td className="py-3">{item.stock}</td>
                    <td className="py-3">
                      <div className="flex flex-wrap gap-1">
                        {item.is_featured && <span className="text-xs bg-purple-100 text-purple-700 px-2 py-1 rounded">Featured</span>}
                        {item.is_best_seller && <span className="text-xs bg-green-100 text-green-700 px-2 py-1 rounded">Best</span>}
                        {item.is_new && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">New</span>}
                      </div>
                    </td>
                    <td className="py-3">
                      {item.is_active ? (
                        <span className="text-xs bg-emerald-100 text-emerald-700 px-2 py-1 rounded">Active</span>
                      ) : (
                        <span className="text-xs bg-red-100 text-red-700 px-2 py-1 rounded">Inactive</span>
                      )}
                    </td>
                    <td className="py-3">
                      <div className="flex gap-2">
                        <Link to={`/admin/products/create?edit=${item.id}`} className="px-3 py-1 rounded bg-gray-200 hover:bg-gray-300">
                          Edit
                        </Link>
                        <Link to={`/admin/products/create?gallery=${item.id}`} className="px-3 py-1 rounded bg-blue-100 text-blue-700 hover:bg-blue-200">
                          Gallery
                        </Link>
                        <button onClick={() => handleDelete(item.id)} className="px-3 py-1 rounded bg-red-500 text-white hover:bg-red-600">
                          Delete
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}

export default AdminProducts;
