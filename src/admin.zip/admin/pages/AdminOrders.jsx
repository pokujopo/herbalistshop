
import { useEffect, useMemo, useState } from "react";
import adminApi from "../services/adminApi";

function StatusBadge({ status }) {
  const styles = {
    pending: "bg-yellow-100 text-yellow-700",
    processing: "bg-purple-100 text-purple-700",
    shipped: "bg-blue-100 text-blue-700",
    delivered: "bg-green-100 text-green-700",
    cancelled: "bg-red-100 text-red-700",
    paid: "bg-green-100 text-green-700",
    failed: "bg-red-100 text-red-700",
  };

  return (
    <span className={`text-xs px-2 py-1 rounded-full ${styles[status] || "bg-gray-100 text-gray-700"}`}>
      {status}
    </span>
  );
}

function AdminOrders() {
  const [orders, setOrders] = useState([]);
  const [loading, setLoading] = useState(true);

  const [query, setQuery] = useState("");
  const [status, setStatus] = useState("all");

  const [selectedOrder, setSelectedOrder] = useState(null);
  const [detailsLoading, setDetailsLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const fetchOrders = async () => {
    try {
      setLoading(true);

      const params = new URLSearchParams();
      if (query.trim()) params.set("search", query.trim());
      if (status !== "all") params.set("status", status);

      const res = await adminApi.get(`/admin/orders?${params.toString()}`);
      setOrders(res.data?.data || []);
    } catch (error) {
      console.log(error.response?.data || error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchOrders();
  }, []);

  const handleSearch = (e) => {
    e.preventDefault();
    fetchOrders();
  };

  const openOrder = async (id) => {
    try {
      setDetailsLoading(true);
      const res = await adminApi.get(`/admin/orders/${id}`);
      setSelectedOrder(res.data.order);
    } catch (error) {
      console.log(error.response?.data || error);
      alert("Failed to load order details");
    } finally {
      setDetailsLoading(false);
    }
  };

  const handleOrderFieldChange = (field, value) => {
    setSelectedOrder((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  const saveOrderUpdates = async () => {
    if (!selectedOrder) return;

    try {
      setSaving(true);

      const res = await adminApi.put(`/admin/orders/${selectedOrder.id}`, {
        order_status: selectedOrder.order_status,
        payment_status: selectedOrder.payment_status,
        tracking_number: selectedOrder.tracking_number || "",
      });

      setSelectedOrder(res.data.order);
      await fetchOrders();
      alert("Order updated successfully");
    } catch (error) {
      console.log(error.response?.data || error);
      alert(error.response?.data?.message || "Failed to update order");
    } finally {
      setSaving(false);
    }
  };

  const totalOrders = useMemo(() => orders.length, [orders]);

  return (
    <div className="space-y-5">
      <div className="bg-white rounded-2xl shadow-sm p-5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-xl font-bold text-gray-800">Orders</h2>
            <p className="text-sm text-gray-500">Simamia orders zote za wateja</p>
          </div>

          <div className="text-sm text-gray-500">
            Total: {totalOrders}
          </div>
        </div>

        <form onSubmit={handleSearch} className="mt-5 grid md:grid-cols-3 gap-4">
          <input
            type="text"
            placeholder="Search order number, customer, phone..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
          />

          <select
            value={status}
            onChange={(e) => setStatus(e.target.value)}
            className="border rounded-xl px-4 py-3 outline-none focus:ring-2 focus:ring-green-500"
          >
            <option value="all">All Status</option>
            <option value="pending">Pending</option>
            <option value="processing">Processing</option>
            <option value="shipped">Shipped</option>
            <option value="delivered">Delivered</option>
            <option value="cancelled">Cancelled</option>
          </select>

          <button
            type="submit"
            className="bg-green-600 text-white rounded-xl py-3 font-semibold hover:bg-green-700"
          >
            Search
          </button>
        </form>
      </div>

      <div className="bg-white rounded-2xl shadow-sm p-5">
        {loading ? (
          <p className="text-gray-500">Loading orders...</p>
        ) : orders.length === 0 ? (
          <p className="text-gray-500">Hakuna orders zilizopatikana.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm min-w-[1000px]">
              <thead>
                <tr className="text-left text-gray-500 border-b">
                  <th className="py-3">Order</th>
                  <th className="py-3">Customer</th>
                  <th className="py-3">Phone</th>
                  <th className="py-3">Order Status</th>
                  <th className="py-3">Payment</th>
                  <th className="py-3">Total</th>
                  <th className="py-3">Date</th>
                  <th className="py-3">Action</th>
                </tr>
              </thead>
              <tbody>
                {orders.map((item) => (
                  <tr key={item.id} className="border-b last:border-0">
                    <td className="py-3 font-semibold">{item.order_number}</td>
                    <td className="py-3">{item.address?.full_name || item.user?.name || "-"}</td>
                    <td className="py-3">{item.address?.phone || "-"}</td>
                    <td className="py-3">
                      <StatusBadge status={item.order_status} />
                    </td>
                    <td className="py-3">
                      <div className="flex flex-col gap-1">
                        <span className="capitalize">{item.payment_method}</span>
                        <StatusBadge status={item.payment_status} />
                      </div>
                    </td>
                    <td className="py-3">
                      TZS {Number(item.total).toLocaleString()}
                    </td>
                    <td className="py-3">
                      {new Date(item.created_at).toLocaleDateString()}
                    </td>
                    <td className="py-3">
                      <button
                        onClick={() => openOrder(item.id)}
                        className="px-3 py-1 rounded bg-blue-100 text-blue-700 hover:bg-blue-200"
                      >
                        View
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* DETAILS PANEL */}
      {(detailsLoading || selectedOrder) && (
        <div className="bg-white rounded-2xl shadow-sm p-5">
          {detailsLoading ? (
            <p className="text-gray-500">Loading order details...</p>
          ) : selectedOrder ? (
            <div className="space-y-6">
              <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-3">
                <div>
                  <h3 className="text-lg font-bold text-gray-800">
                    Order #{selectedOrder.order_number}
                  </h3>
                  <p className="text-sm text-gray-500">
                    {selectedOrder.address?.full_name} • {selectedOrder.address?.phone}
                  </p>
                </div>

                <button
                  onClick={() => setSelectedOrder(null)}
                  className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300"
                >
                  Close
                </button>
              </div>

              <div className="grid md:grid-cols-3 gap-4">
                <div>
                  <label className="text-sm text-gray-500">Order Status</label>
                  <select
                    value={selectedOrder.order_status}
                    onChange={(e) => handleOrderFieldChange("order_status", e.target.value)}
                    className="mt-1 w-full border rounded-xl px-4 py-3"
                  >
                    <option value="pending">Pending</option>
                    <option value="processing">Processing</option>
                    <option value="shipped">Shipped</option>
                    <option value="delivered">Delivered</option>
                    <option value="cancelled">Cancelled</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-500">Payment Status</label>
                  <select
                    value={selectedOrder.payment_status}
                    onChange={(e) => handleOrderFieldChange("payment_status", e.target.value)}
                    className="mt-1 w-full border rounded-xl px-4 py-3"
                  >
                    <option value="pending">Pending</option>
                    <option value="paid">Paid</option>
                    <option value="failed">Failed</option>
                  </select>
                </div>

                <div>
                  <label className="text-sm text-gray-500">Tracking Number</label>
                  <input
                    type="text"
                    value={selectedOrder.tracking_number || ""}
                    onChange={(e) => handleOrderFieldChange("tracking_number", e.target.value)}
                    className="mt-1 w-full border rounded-xl px-4 py-3"
                    placeholder="Tracking number"
                  />
                </div>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="bg-gray-50 rounded-2xl p-4">
                  <h4 className="font-semibold text-gray-800 mb-3">Delivery Address</h4>
                  <div className="text-sm text-gray-600 space-y-1">
                    <p>{selectedOrder.address?.full_name}</p>
                    <p>{selectedOrder.address?.phone}</p>
                    <p>{selectedOrder.address?.street_address}</p>
                    <p>{selectedOrder.address?.city}, {selectedOrder.address?.region}</p>
                    {selectedOrder.address?.notes && <p>Notes: {selectedOrder.address.notes}</p>}
                  </div>
                </div>

                <div className="bg-gray-50 rounded-2xl p-4">
                  <h4 className="font-semibold text-gray-800 mb-3">Payment Summary</h4>
                  <div className="text-sm text-gray-600 space-y-2">
                    <p>Method: <span className="capitalize">{selectedOrder.payment_method}</span></p>
                    <p>Subtotal: TZS {Number(selectedOrder.subtotal).toLocaleString()}</p>
                    <p>Delivery: TZS {Number(selectedOrder.delivery_fee).toLocaleString()}</p>
                    <p className="font-semibold text-gray-800">
                      Total: TZS {Number(selectedOrder.total).toLocaleString()}
                    </p>
                  </div>
                </div>
              </div>

              <div>
                <h4 className="font-semibold text-gray-800 mb-3">Ordered Items</h4>

                <div className="space-y-3">
                  {selectedOrder.items?.map((item) => (
                    <div
                      key={item.id}
                      className="flex items-center gap-4 bg-gray-50 rounded-2xl p-3"
                    >
                      <div className="w-16 aspect-square rounded-xl overflow-hidden bg-gray-100">
                        <img
                          src={item.product?.thumbnail || item.product_image_url || item.product_image}
                          alt={item.product?.name || item.product_name}
                          className="w-full h-full object-cover"
                        />
                      </div>

                      <div className="flex-1">
                        <p className="font-medium text-gray-800">
                          {item.product?.name || item.product_name}
                        </p>
                        <p className="text-sm text-gray-500">
                          Qty: {item.quantity}
                        </p>
                      </div>

                      <div className="text-sm font-semibold text-gray-800">
                        TZS {Number(item.subtotal).toLocaleString()}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <button
                onClick={saveOrderUpdates}
                disabled={saving}
                className="bg-green-600 text-white px-6 py-3 rounded-xl hover:bg-green-700 disabled:opacity-60"
              >
                {saving ? "Saving..." : "Save Changes"}
              </button>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
}

export default AdminOrders;