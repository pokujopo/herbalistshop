import { Link, useLocation } from "react-router-dom";

function AdminSidebar() {
  const location = useLocation();

  const links = [
    { name: "Dashboard", path: "/admin" },
    { name: "Products", path: "/admin/products" },
    { name: "Create Product", path: "/admin/products/create" },
    { name: "Orders", path: "/admin/orders" },
    { name: "Categories", path: "/admin/categories" },
    { name: "Customers", path: "/admin/users" },
    { name: "Newsletters", path: "/admin/newsletters" },
    { name: "Coupons", path: "/admin/coupons" },
    { name: "Settings", path: "/admin/settings" },
  ];

  return (
    <aside className="w-full md:w-64 bg-[#0f172a] text-white min-h-screen p-5">
      <h2 className="text-xl font-bold mb-8">Admin Panel</h2>

      <nav className="flex flex-col gap-2">
        {links.map((link) => {
          const active = location.pathname === link.path;

          return (
            <Link
              key={link.path}
              to={link.path}
              className={`px-4 py-3 rounded-xl transition ${
                active
                  ? "bg-green-600 text-white"
                  : "text-gray-300 hover:bg-white/10 hover:text-white"
              }`}
            >
              {link.name}
            </Link>
          );
        })}
      </nav>
    </aside>
  );
}

export default AdminSidebar;
